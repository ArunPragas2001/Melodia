const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const http = require("node:http");
const { chromium } = require("playwright");
const root = path.resolve(process.env.MELODIA_EXPORT_DIR || "dist");
assert(
  fs.existsSync(path.join(root, "index.html")),
  "Export web first (expo export --platform web)",
);
const mime = {
  ".html": "text/html",
  ".js": "application/javascript",
  ".json": "application/json",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".ttf": "font/ttf",
  ".ico": "image/x-icon",
};
const server = http.createServer((req, res) => {
  const file = path.resolve(
    root,
    "." + new URL(req.url, "http://localhost").pathname,
  );
  if (!file.startsWith(root + path.sep) && file !== root) {
    res.writeHead(403).end();
    return;
  }
  const target =
    fs.existsSync(file) && fs.statSync(file).isFile()
      ? file
      : path.join(root, "index.html");
  res.setHeader(
    "Content-Type",
    mime[path.extname(target)] || "application/octet-stream",
  );
  fs.createReadStream(target).pipe(res);
});
(async () => {
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  let browser;
  try {
    browser = await chromium.launch({
      executablePath:
        process.env.CHROMIUM_PATH ||
        (fs.existsSync("/usr/bin/chromium") ? "/usr/bin/chromium" : undefined),
      headless: true,
      args: ["--no-sandbox"],
    });
    const page = await browser.newPage({
      viewport: { width: 390, height: 844 },
    });
    page.setDefaultTimeout(10000);
    const errors = [];
    page.on("pageerror", (error) => errors.push(error.message));
    const base = `http://127.0.0.1:${server.address().port}`;
    const expectText = (text) =>
      page.getByText(text, { exact: true }).filter({ visible: true }).waitFor();
    await page.goto(base);
    await expectText("Sign in to Melodia.");
    await page.getByText("Create an account", { exact: true }).click();
    await expectText("Create an account.");
    await page.getByRole("button", { name: "Create account" }).click();
    await expectText("Enter your name");
    await page.getByRole("textbox", { name: "Name" }).fill("Alex Rivera");
    await page.getByRole("textbox", { name: "Email" }).fill("alex@example.com");
    await page
      .getByLabel("Password", { exact: true })
      .filter({ visible: true })
      .fill("musicpass123");
    await page.getByLabel("Confirm password").fill("musicpass123");
    await page.getByRole("button", { name: "Create account" }).click();
    await expectText("Discover your sound.");
    await page.reload();
    await expectText("Discover your sound.");
    await page
      .getByRole("button", { name: "Browse string instruments", exact: true })
      .click();
    await expectText("3 instruments to discover");
    await page.getByRole("button", { name: "All", exact: true }).click();
    await expectText("12 instruments to discover");
    const cards = page.locator('[data-testid="instrument-list"] [aria-label^="View "]');
    assert.equal(await cards.first().getAttribute("aria-label"), "View Accordion");
    await page.getByRole("button", { name: "Sort instruments Z to A" }).click();
    assert.equal(await cards.first().getAttribute("aria-label"), "View Xylophone");
    await page.getByRole("button", { name: "Sort instruments A to Z" }).click();
    await page
      .getByTestId("instrument-list")
      .getByText("Guitar", { exact: true })
      .waitFor();
    await page.waitForFunction(() => {
      const images = Array.from(
        document.querySelectorAll('[data-testid="instrument-list"] img'),
      );
      return (
        images.length >= 12 &&
        images.every((image) => image.complete && image.naturalWidth > 0)
      );
    });
    for (const family of ["Strings", "Wind", "Percussion", "Keyboard"]) {
      await page.goto(base + "/categories");
      await expectText("Every sound has a family.");
      await page
        .getByRole("button", { name: family + " →", exact: true })
        .click();
      await expectText("3 instruments to discover");
      await page.reload();
      await expectText("3 instruments to discover");
    }
    await page.goto(base + "/explore?family=unknown");
    await expectText("12 instruments to discover");
    await page.getByRole("button", { name: "Wind", exact: true }).click();
    await expectText("3 instruments to discover");
    await page.getByText("Show all families →", { exact: true }).click();
    await expectText("12 instruments to discover");

    await page.goto(base + "/search");
    const search = page.getByRole("textbox", {
      name: "Search instruments by name",
    });
    await search.fill("  GUITAR  ");
    await expectText("1 result");
    await page.getByRole("button", { name: "View Guitar" }).click();
    await expectText("How to play");
    await expectText("Four open-string notes");
    await expectText("Demonstration");
    await expectText("Beginner tip");
    await page.getByRole("button", { name: "Save to favourites" }).click();
    await expectText("Remove from favourites");
    await page.goto(base + "/favourites");
    await expectText("1 saved instrument");
    await page.reload();
    await expectText("1 saved instrument");
    await page.goto(base + "/search");
    await page.getByRole("button", { name: "Wind", exact: true }).click();
    await expectText("3 results");
    await search.fill("sax");
    await expectText("1 result");
    await page.getByRole("button", { name: "Clear search" }).click();
    await expectText("3 results");
    await search.fill("not in the library");
    await expectText("No instruments found");

    await page.goto(base + "/details?id=missing");
    await expectText("Instrument not found");
    await page.getByRole("button", { name: "Return to Explore" }).click();
    await expectText("12 instruments to discover");

    await page.goto(base + "/quiz");
    const correctAnswers = [
      "Violin",
      "Percussion",
      "Hammers",
      "Saxophone",
      "Frets",
      "Accordion",
      "Buzz their lips",
      "Wood",
    ];
    for (let index = 0; index < correctAnswers.length; index += 1) {
      await page
        .getByRole("button", { name: correctAnswers[index], exact: true })
        .click();
      await expectText("Correct!");
      await page
        .getByRole("button", {
          name: index === correctAnswers.length - 1 ? "View result" : "Next question",
        })
        .click();
    }
    await expectText("8/8");
    await page.goto(base + "/profile");
    await expectText("Alex Rivera");
    await expectText("8/8");
    await page.getByRole("button", { name: "Sign out" }).click();
    await expectText("Sign in to Melodia.");
    await page.getByRole("textbox", { name: "Email" }).fill("alex@example.com");
    await page
      .getByLabel("Password", { exact: true })
      .filter({ visible: true })
      .fill("wrong password");
    await page.getByRole("button", { name: "Sign in" }).click();
    await expectText("Email or password is incorrect");
    await page
      .getByLabel("Password", { exact: true })
      .filter({ visible: true })
      .fill("musicpass123");
    await page.getByRole("button", { name: "Sign in" }).click();
    await expectText("Discover your sound.");
    await page.goto(base + "/profile");
    await expectText("8/8");

    for (const width of [320, 390, 820]) {
      await page.setViewportSize({ width, height: 844 });
      for (const route of [
        "/",
        "/explore",
        "/categories",
        "/search",
        "/details?id=guitar",
        "/favourites",
        "/profile",
      ]) {
        await page.goto(base + route);
        await expectText(
          route === "/"
            ? "Discover your sound."
            : route === "/explore"
              ? "12 instruments to discover"
              : route === "/categories"
                ? "Every sound has a family."
                : route === "/search"
                  ? "Find an instrument."
                  : route === "/favourites"
                    ? "Favourites."
                    : route === "/profile"
                      ? "Alex Rivera"
                  : "How to play",
        );
        assert(
          await page.evaluate(
            () => document.documentElement.scrollWidth <= innerWidth,
          ),
          route + " must not overflow at " + width + "px",
        );
      }
    }
    assert.deepEqual(errors, []);
    console.log(
      "PASS: accounts, browsing, search, details, favourites, quiz, profile, persistence and responsive layouts; no page errors.",
    );
  } finally {
    if (browser) await browser.close();
    await new Promise((resolve) => server.close(resolve));
  }
})().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
